# Pizza · interactive Web UI prototype

Five connected screens: Welcome → Select a Disk → Slice Your Disk → Review & Confirm → All Set. A short simulated apply transition connects review to completion.

Run from this directory with `python3 -m http.server 4173 --bind 127.0.0.1`, then open http://127.0.0.1:4173.

No build, package installation, CDN or network fonts are required. All disk data is fictional, held in memory and reset on reload. The prototype cannot access or modify real drives. Exported JSON is marked non-executable and is not the backend's plan schema.

- Disk selection, slice selection, divider dragging / number input, naming, file systems, contextual left / right add, delete / reset, review and JSON export work.
- System slices are protected in this prototype. Dragging a divider redistributes capacity between its two adjacent slices. Number entry shrinks into new adjacent free space or grows into adjacent free spans. Physical sector alignment, file-system constraints and real move feasibility require the real planner.
- Slice sizes always sum to disk capacity. Only the editor dims unselected slices; welcome, review, transition and completion use opaque artwork.
- The food is native SVG: original ingredient silhouettes from the supplied `New project 3/src/Pizza.tsx`, composed into responsive wedges, with simpler shading and no native relief or 3D runtime. Fonts and their OFL licenses are bundled under `assets/fonts`.
- English copy follows the supplied keyframes. This is a visual / interaction prototype, not the production frontend or maintenance environment.

`index.html` is the shell, `style.css` the responsive visual system, `app.js` the sample interaction model, and `pizza.js` the procedural artwork. No real disk backend is connected.

## Preview captures

The `screenshots/` folder contains the five desktop scenes and the narrow-screen editor. They are captures of the working HTML prototype, not generated mockups.

Selection updates preserve disk cards, the pizza SVG and inspector inputs. Slice opacity and position transition over 200 / 260 ms without restarting the page entrance animation. Repeated selection, focus retention, label edits and subsequent resize / add / delete actions were checked in the browser; SVG paint definitions stay unchanged across selections. `07-selection-fix.png` captures the updated editor.

The file-system picker uses a matching warm paper menu with a brick-red selection check. `format-picker.js` implements the select-only combobox / listbox, arrow and Home / End navigation, type-to-search, Enter / Space selection, Escape cancellation, Tab / outside dismissal and disabled states. Mouse and keyboard selection were checked against the review plan. The menu repositions above the field when space below is limited.

The editor identifies each slice with an external callout: name, capacity and file system, connected by an elbow leader to the slice's actual angular midpoint. Text stays outside the pizza and remains opaque. Labels can also select a slice; selecting preserves SVG resources. Resizing, renaming, changing file systems and adding / removing partitions update the callouts. Checked the 0.1 GB free-space boundary and desktop / narrow layouts. `09-external-callouts.png` shows this design.

`partition-bar.js` provides draggable dividers, keyboard adjustment (arrows, Shift + arrows, Home / End), and a segment context menu. Add left / right takes capacity from the clicked free span, or splits the clicked allocated partition while keeping at least 10 GB. New slices are inserted on the requested side; deleting returns capacity to free space at that position and merges adjoining free spans. Right-click, Shift + F10, a long press, or the three-dot button opens the same menu. The menu is attached to `body` so page animations cannot offset its viewport coordinates; it flips beside the pointer at window edges. Checked real pointer dragging, both insertion directions, deletion / merge, minimum / maximum sizes, protected System, review output and total capacity. Desktop and narrow layouts place the menu within about 6 px of the invocation point. `10-partition-bar-menu.png` shows this interaction.

Verified in the browser: disk switching, selecting slices, numeric and keyboard resizing, 0 GB and 0.1 GB free-space boundaries, naming, changing file systems, adding and deleting slices, review contents, simulated completion, opacity rules and the help dialog. Checked desktop and 390 px responsive layouts; the browser reported no JavaScript errors. JavaScript syntax checks also pass.
